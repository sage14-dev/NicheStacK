import React, { useState } from 'react';
import Header from './components/Header';
import ExecutiveSummary from './components/ExecutiveSummary';
import NicheValidation from './components/NicheValidation';
import ToolRoadmap from './components/ToolRoadmap';
import RiskAnalysis from './components/RiskAnalysis';
import FinancialCalculator from './components/FinancialCalculator';
import SeoMatrix from './components/SeoMatrix';
import LiveDemoSuite from './components/LiveDemoSuite';
import { exportExecutiveReport } from './utils/reportExporter';
import { Layers, Rocket, ShieldCheck, Zap, Heart } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('summary');
  const [toastMessage, setToastMessage] = useState(null);

  const handleExport = () => {
    exportExecutiveReport();
    setToastMessage('Executive Report downloaded as Markdown/PDF file!');
    setTimeout(() => setToastMessage(null), 4000);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Header Bar */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} onExportReport={handleExport} />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-600 text-white px-4 py-3 rounded-xl shadow-2xl flex items-center space-x-2 text-xs font-bold animate-bounce">
          <ShieldCheck className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'summary' && <ExecutiveSummary setActiveTab={setActiveTab} />}
        {activeTab === 'validation' && <NicheValidation setActiveTab={setActiveTab} />}
        {activeTab === 'tools' && <ToolRoadmap setActiveTab={setActiveTab} />}
        {activeTab === 'risks' && <RiskAnalysis setActiveTab={setActiveTab} />}
        {activeTab === 'calculator' && <FinancialCalculator />}
        {activeTab === 'seo' && <SeoMatrix />}
        {activeTab === 'demo' && <LiveDemoSuite />}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-8 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 rounded-md bg-indigo-600 flex items-center justify-center text-white">
              <Layers className="w-3.5 h-3.5" />
            </div>
            <span className="font-bold text-slate-200">NicheStack Strategy & File Converter Suite</span>
            <span>•</span>
            <span className="text-slate-500">SaaS Feasibility Platform</span>
          </div>

          <div className="flex items-center space-x-4">
            <button onClick={() => setActiveTab('summary')} className="hover:text-white transition-colors">Executive Brief</button>
            <button onClick={() => setActiveTab('validation')} className="hover:text-white transition-colors">Niche Validation</button>
            <button onClick={() => setActiveTab('demo')} className="text-emerald-400 font-bold hover:underline">⚡ Live MVP Suite</button>
          </div>
        </div>
      </footer>
    </div>
  );
}
