import React from 'react';
import { RISKS_AND_ADVANTAGES } from '../data/strategyData';
import { ShieldAlert, ShieldCheck, AlertTriangle, Cpu, Globe, Users, Lock, CheckCircle2, ArrowRight } from 'lucide-react';

export default function RiskAnalysis({ setActiveTab }) {
  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
          <span>Requirement 3 Assessment</span>
          <span>•</span>
          <span>Risks, Moats & Saturation Analysis</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white">Honest Strategic Risk Assessment & Defensibility Moats</h2>
        <p className="text-slate-400 text-sm max-w-3xl leading-relaxed">
          Direct analysis of technical, regulatory, and market risks. We evaluate whether this niche is saturated and highlight the unfair advantages that make it viable.
        </p>
      </div>

      {/* Saturation Verdict Banner */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <Globe className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Is the Real Estate File Utility Market Saturated?</h3>
            <p className="text-xs text-slate-400">Competitive Landscape & Vertical Dominance Evaluation</p>
          </div>
        </div>
        <div className="p-4 rounded-xl bg-slate-800/60 text-xs text-slate-300 leading-relaxed space-y-2">
          <p>
            <strong className="text-white">Short Answer: NO, but with a nuanced caveat.</strong> Generic giants like SmallPDF, iLovePDF, and CloudConvert dominate high-level queries ("compress PDF", "convert PNG to JPG"). However, <strong className="text-indigo-300">zero dominant vertical players</strong> own the long-tail MLS and realtor file utility space.
          </p>
          <p>
            Most real estate agents currently rely on clunky 2010-era desktop utilities provided by individual MLS portals or manual trial-and-error resizing in Microsoft Paint/Preview. By branding specifically for real estate agents ("The Realtor File Suite"), you bypass generic competition and capture intent at the exact moment of workflow frustration.
          </p>
        </div>
      </div>

      {/* Grid: Key Operational Risks vs Unfair Advantages */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: Identified Risks & Mitigation */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 text-amber-400 font-bold text-sm uppercase tracking-wide">
            <ShieldAlert className="w-5 h-5" />
            <span>Operational & Technical Risks</span>
          </div>

          <div className="space-y-4">
            {RISKS_AND_ADVANTAGES.risks.map((risk, idx) => (
              <div key={idx} className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>{risk.title}</span>
                  </h4>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    risk.severity === 'High'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}>
                    {risk.severity} Severity
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{risk.description}</p>
                <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-200">
                  <span className="font-bold text-emerald-300">Mitigation Strategy: </span>
                  {risk.mitigation}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Unfair Advantages & Defensibility Moats */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 text-emerald-400 font-bold text-sm uppercase tracking-wide">
            <ShieldCheck className="w-5 h-5" />
            <span>Unfair Defensibility Moats</span>
          </div>

          <div className="space-y-4">
            {RISKS_AND_ADVANTAGES.unfairAdvantages.map((adv, idx) => (
              <div key={idx} className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{adv.title}</span>
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">{adv.description}</p>
              </div>
            ))}

            {/* Privacy Moat Card */}
            <div className="p-5 rounded-xl bg-indigo-950/40 border border-indigo-500/30 space-y-2">
              <h4 className="font-bold text-indigo-300 text-sm flex items-center space-x-2">
                <Lock className="w-4 h-4 text-indigo-400" />
                <span>The Privacy & Legal Compliance Moat</span>
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Brokerages are terrified of uploading sensitive client disclosures, purchase contracts, and wire instruction PDFs to third-party cloud servers. Because your suite runs 100% in-browser via WebAssembly, documents never touch an external server—making it instantly compliant with brokerage IT security policies.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Decision Trade-offs Synthesis */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-indigo-950 via-slate-900 to-slate-900 border border-indigo-500/30 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="text-sm font-bold text-white">Strategic Verdict: Proceed with Client-Side Real Estate Suite</div>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            The low engineering complexity combined with near-zero server infrastructure costs makes this a low-risk, high-upside SaaS project.
          </p>
        </div>
        <button
          onClick={() => setActiveTab('calculator')}
          className="whitespace-nowrap px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition-all active:scale-95"
        >
          View Financial ROI Model →
        </button>
      </div>
    </div>
  );
}
