import React, { useState } from 'react';
import { PROFESSIONS_EVALUATION } from '../data/strategyData';
import { CheckCircle2, AlertCircle, Award, Search, DollarSign, RefreshCw, Filter, ArrowUpRight, Check, X } from 'lucide-react';

export default function NicheValidation({ setActiveTab }) {
  const [selectedProf, setSelectedProf] = useState(PROFESSIONS_EVALUATION[0]);
  const [sortBy, setSortBy] = useState('score');

  const sortedProfessions = [...PROFESSIONS_EVALUATION].sort((a, b) => {
    if (sortBy === 'score') return b.score - a.score;
    if (sortBy === 'demand') return parseFloat(b.monthlySearches) - parseFloat(a.monthlySearches);
    if (sortBy === 'pay') return b.willingnessToPay - a.willingnessToPay;
    return 0;
  });

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Section Header */}
      <div className="space-y-2">
        <div className="flex items-center space-x-2 text-indigo-400 text-xs font-bold uppercase tracking-wider">
          <span>Requirement 1 Validation</span>
          <span>•</span>
          <span>4 Professions Evaluated</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white">Niche Selection & Professional Vertical Validation</h2>
        <p className="text-slate-400 text-sm max-w-3xl leading-relaxed">
          We evaluated 4 candidate professional audiences against strict SaaS selection criteria: recurring workflow urgency, verified search volume, willingness to pay, and generic tool SEO gaps.
        </p>
      </div>

      {/* Sorting & Quick Filter */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800">
        <div className="flex items-center space-x-2 text-xs text-slate-300 font-semibold">
          <Filter className="w-4 h-4 text-indigo-400" />
          <span>Sort Verticals By:</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'score', label: 'Overall Strategy Score' },
            { id: 'pay', label: 'Willingness To Pay' },
            { id: 'demand', label: 'Search Demand' }
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setSortBy(item.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                sortBy === item.id
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Professions Cards Comparison Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {sortedProfessions.map((prof) => {
          const isSelected = selectedProf.id === prof.id;
          return (
            <div
              key={prof.id}
              onClick={() => setSelectedProf(prof)}
              className={`cursor-pointer rounded-2xl p-5 border transition-all duration-200 flex flex-col justify-between space-y-4 ${
                isSelected
                  ? 'bg-indigo-950/40 border-indigo-500/80 shadow-xl shadow-indigo-500/10 ring-1 ring-indigo-500/50'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <span className={`text-2xl font-black ${prof.winner ? 'text-emerald-400' : 'text-slate-300'}`}>
                    {prof.score} <span className="text-xs text-slate-500 font-normal">/ 10</span>
                  </span>
                  {prof.winner && (
                    <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30 flex items-center space-x-1">
                      <Award className="w-3 h-3 text-emerald-400" />
                      <span>TOP PICK</span>
                    </span>
                  )}
                </div>

                <div>
                  <h3 className="font-bold text-white text-base leading-snug">{prof.title}</h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">{prof.tagline}</p>
                </div>

                {/* Score Indicators */}
                <div className="space-y-1.5 pt-2 border-t border-slate-800/80 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Workflow Frequency:</span>
                    <span className="font-semibold text-slate-200">{prof.workflowNeed}/10</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Search Demand:</span>
                    <span className="font-semibold text-slate-200">{prof.searchDemand}/10</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Willingness to Pay:</span>
                    <span className="font-semibold text-indigo-300">{prof.willingnessToPay}/10</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Generic SEO Gap:</span>
                    <span className="font-semibold text-purple-300">{prof.genericGap}/10</span>
                  </div>
                </div>
              </div>

              <button
                className={`w-full py-2 rounded-lg text-xs font-semibold transition-all ${
                  isSelected
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {isSelected ? 'Selected Deep Dive' : 'Inspect Rationale'}
              </button>
            </div>
          );
        })}
      </div>

      {/* Selected Vertical Deep Rationale */}
      <div className="p-6 sm:p-8 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <div className="space-y-1">
            <div className="flex items-center space-x-3">
              <h3 className="text-2xl font-black text-white">{selectedProf.title}</h3>
              {selectedProf.winner && (
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
                  Recommended Target Vertical
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400">{selectedProf.tagline}</p>
          </div>

          <div className="flex items-center space-x-4 bg-slate-800/60 p-3 rounded-xl border border-slate-700/50 text-xs">
            <div>
              <div className="text-slate-400">Est. Search Vol</div>
              <div className="font-bold text-white text-sm">{selectedProf.monthlySearches}</div>
            </div>
            <div className="w-px h-8 bg-slate-700" />
            <div>
              <div className="text-slate-400">Avg Google CPC</div>
              <div className="font-bold text-emerald-400 text-sm">{selectedProf.avgCpc}</div>
            </div>
            <div className="w-px h-8 bg-slate-700" />
            <div>
              <div className="text-slate-400">Est. MRR Cap</div>
              <div className="font-bold text-amber-300 text-sm">{selectedProf.estMrrPotential}</div>
            </div>
          </div>
        </div>

        {/* Detailed Criteria Checklist */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h4 className="font-bold text-white text-sm flex items-center space-x-2">
              <RefreshCw className="w-4 h-4 text-indigo-400" />
              <span>Core Workflow Pain Points & Daily Use Cases</span>
            </h4>
            <ul className="space-y-2.5">
              {selectedProf.primaryPainPoints.map((pt, idx) => (
                <li key={idx} className="flex items-start space-x-2.5 text-xs text-slate-300">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{pt}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="font-bold text-white text-sm flex items-center space-x-2">
              <Search className="w-4 h-4 text-purple-400" />
              <span>Why Generic Tools (SmallPDF/iLovePDF) Fail Here</span>
            </h4>
            <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700 text-xs text-slate-300 leading-relaxed">
              {selectedProf.whyGenericToolsFail}
            </div>

            <h4 className="font-bold text-white text-sm flex items-center space-x-2 pt-2">
              <DollarSign className="w-4 h-4 text-amber-400" />
              <span>Monetization & Willingness to Pay Rationale</span>
            </h4>
            <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700 text-xs text-slate-300 leading-relaxed">
              {selectedProf.monetizationPotential}
            </div>
          </div>
        </div>

        {/* Comparison Rationale Summary Box */}
        {selectedProf.winner && (
          <div className="p-5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="font-bold text-emerald-300 text-sm">Strategic Recommendation</div>
              <p className="text-xs text-emerald-200/80 leading-relaxed">
                Real Estate Agents win cleanly on overall revenue potential, immediate SEO long-tail search dominance, and low sales friction ($19/mo expense write-off per agent).
              </p>
            </div>
            <button
              onClick={() => setActiveTab('tools')}
              className="whitespace-nowrap px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all active:scale-95"
            >
              Proceed to 5-Tool Blueprint →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
