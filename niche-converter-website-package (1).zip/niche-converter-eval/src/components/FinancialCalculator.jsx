import React, { useState } from 'react';
import { DollarSign, TrendingUp, Users, PieChart, ShieldCheck, Zap, RefreshCw } from 'lucide-react';

export default function FinancialCalculator() {
  const [traffic, setTraffic] = useState(50000); // 50,000 monthly visitors
  const [adCpm, setAdCpm] = useState(12.00); // $12 CPM
  const [proConv, setProConv] = useState(1.8); // 1.8% conversion to $19 Pro
  const [proPrice, setProPrice] = useState(19); // $19/mo
  const [teamPrice, setTeamPrice] = useState(89); // $89/mo Team
  const [teamConv, setTeamConv] = useState(0.2); // 0.2% conversion to Team

  // Calculations
  const monthlyAdRev = (traffic / 1000) * adCpm * 1.5; // average 1.5 pageviews per visitor
  const proSubscribers = Math.round(traffic * (proConv / 100));
  const monthlyProMrr = proSubscribers * proPrice;

  const teamSubscribers = Math.round(traffic * (teamConv / 100));
  const monthlyTeamMrr = teamSubscribers * teamPrice;

  const totalMrr = monthlyProMrr + monthlyTeamMrr;
  const totalMonthlyRev = totalMrr + monthlyAdRev;
  const arr = totalMonthlyRev * 12;

  // Estimated server cost (near zero because client-side WASM processing)
  const estServerCost = Math.max(29, Math.round(traffic * 0.0004));
  const grossProfitMargin = (((totalMonthlyRev - estServerCost) / totalMonthlyRev) * 100).toFixed(1);

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
          <span>Financial Feasibility</span>
          <span>•</span>
          <span>Unit Economics & Revenue Projection Model</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white">Interactive SaaS Monetization & Unit Economics Calculator</h2>
        <p className="text-slate-400 text-sm max-w-3xl leading-relaxed">
          Simulate monthly recurring revenue (MRR) based on organic search traffic, freemium ad CPMs, individual agent subscriptions, and brokerage team licenses.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Controls Column (7 cols) */}
        <div className="lg:col-span-7 p-6 sm:p-8 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
          <h3 className="font-bold text-white text-base flex items-center space-x-2 border-b border-slate-800 pb-4">
            <Zap className="w-5 h-5 text-indigo-400" />
            <span>Monetization Model Sliders</span>
          </h3>

          <div className="space-y-5">
            {/* Slider 1: Monthly Organic Traffic */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-300">Monthly Organic Visitors:</span>
                <span className="text-indigo-400 font-bold">{traffic.toLocaleString()} visitors/mo</span>
              </div>
              <input
                type="range"
                min="5000"
                max="300000"
                step="5000"
                value={traffic}
                onChange={(e) => setTraffic(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>5,000 (Launch)</span>
                <span>50,000 (Target Y1)</span>
                <span>300,000 (Scale)</span>
              </div>
            </div>

            {/* Slider 2: Pro Subscription Conversion Rate */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-300">Agent Pro Conversion Rate:</span>
                <span className="text-purple-400 font-bold">{proConv}%</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="4.0"
                step="0.1"
                value={proConv}
                onChange={(e) => setProConv(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>0.5% (Conservative)</span>
                <span>1.8% (Benchmark)</span>
                <span>4.0% (Aggressive)</span>
              </div>
            </div>

            {/* Slider 3: Pro Monthly Price */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-300">Agent Pro Price:</span>
                <span className="text-emerald-400 font-bold">${proPrice}/month</span>
              </div>
              <input
                type="range"
                min="9"
                max="39"
                step="1"
                value={proPrice}
                onChange={(e) => setProPrice(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
              />
            </div>

            {/* Slider 4: Ad CPM */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-300">Freemium Banner Ad CPM:</span>
                <span className="text-amber-400 font-bold">${adCpm.toFixed(2)} CPM</span>
              </div>
              <input
                type="range"
                min="4"
                max="25"
                step="1"
                value={adCpm}
                onChange={(e) => setAdCpm(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
            </div>

            {/* Slider 5: Brokerage Team Plan Price & Conv */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-300">Brokerage Team Plan (${teamPrice}/mo):</span>
                <span className="text-teal-400 font-bold">{teamConv}% conversion</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={teamConv}
                onChange={(e) => setTeamConv(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-500"
              />
            </div>
          </div>
        </div>

        {/* Results Output Column (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-br from-indigo-950 via-slate-900 to-purple-950 border border-indigo-500/40 space-y-6 shadow-2xl">
            <div className="space-y-1">
              <span className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider">Projected Revenue Output</span>
              <div className="text-3xl sm:text-4xl font-black text-white">
                ${Math.round(totalMonthlyRev).toLocaleString()}
                <span className="text-xs font-semibold text-slate-400"> / month</span>
              </div>
              <div className="text-xs text-emerald-400 font-bold">
                ARR Run-Rate: ${Math.round(arr).toLocaleString()} / year
              </div>
            </div>

            <div className="space-y-3 border-t border-slate-800/80 pt-4 text-xs">
              <div className="flex justify-between items-center p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
                <span className="text-slate-400">Agent Pro Subscriptions ({proSubscribers.toLocaleString()} users):</span>
                <span className="font-bold text-purple-300">${Math.round(monthlyProMrr).toLocaleString()}/mo</span>
              </div>

              <div className="flex justify-between items-center p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
                <span className="text-slate-400">Brokerage Team Plans ({teamSubscribers.toLocaleString()} teams):</span>
                <span className="font-bold text-teal-300">${Math.round(monthlyTeamMrr).toLocaleString()}/mo</span>
              </div>

              <div className="flex justify-between items-center p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
                <span className="text-slate-400">Freemium Ad Revenue:</span>
                <span className="font-bold text-amber-300">${Math.round(monthlyAdRev).toLocaleString()}/mo</span>
              </div>

              <div className="flex justify-between items-center p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
                <span className="text-slate-400">Est. Cloud Hosting Cost:</span>
                <span className="font-bold text-slate-300">${estServerCost}/mo</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between">
              <div>
                <div className="text-[11px] text-emerald-300 font-bold uppercase">Gross Profit Margin</div>
                <div className="text-xs text-slate-300">Client-Side WASM Moat</div>
              </div>
              <div className="text-2xl font-black text-emerald-400">{grossProfitMargin}%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
