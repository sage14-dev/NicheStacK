import React, { useState, useRef, useEffect } from 'react';
import JSZip from 'jszip';
import saveAs from 'file-saver';
import { PDFDocument } from 'pdf-lib';
import { Image, FileText, Sparkles, ShieldCheck, Download, RefreshCw, Upload, CheckCircle2, Zap, Sliders, Eye, Trash2, Layers } from 'lucide-react';

export default function LiveDemoSuite() {
  const [activeSubTab, setActiveDemoTab] = useState('resizer');

  // ========================================================
  // STATE FOR TOOL 1: MLS PHOTO RESIZER & COMPRESSOR
  // ========================================================
  const [resizerFiles, setResizerFiles] = useState([]);
  const [selectedPreset, setSelectedPreset] = useState('bright');
  const [jpegQuality, setJpegQuality] = useState(80);
  const [stripExifInResizer, setStripExifInResizer] = useState(true);
  const [processedImages, setProcessedImages] = useState([]);
  const [isProcessingResizer, setIsProcessingResizer] = useState(false);

  const MLS_PRESETS = {
    bright: { name: 'Bright MLS / Matrix (2048 x 1536)', width: 2048, height: 1536, maxMb: 2 },
    crmls: { name: 'CRMLS Standard (1024 x 768)', width: 1024, height: 768, maxMb: 1.5 },
    stellar: { name: 'Stellar MLS High-Res (1920 x 1080)', width: 1920, height: 1080, maxMb: 3 },
    zillow: { name: 'Zillow & Realtor.com (2048 x 1536)', width: 2048, height: 1536, maxMb: 5 }
  };

  const handleResizerUpload = (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setResizerFiles(files);
    setProcessedImages([]);
  };

  const processResizerBatch = async () => {
    if (!resizerFiles.length) return;
    setIsProcessingResizer(true);

    const preset = MLS_PRESETS[selectedPreset] || MLS_PRESETS.bright;
    const results = [];

    for (let file of resizerFiles) {
      try {
        const img = await loadImage(file);
        const canvas = document.createElement('canvas');

        // Calculate aspect ratio scale to fit inside target preset width/height
        let targetW = preset.width;
        let targetH = preset.height;

        let scale = Math.min(targetW / img.width, targetH / img.height, 1);
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);

        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        const dataUrl = canvas.toDataURL('image/jpeg', jpegQuality / 100);
        const compressedBlob = await (await fetch(dataUrl)).blob();

        results.push({
          name: file.name.replace(/\.[^/.]+$/, "") + `_MLS_${preset.width}x${preset.height}.jpg`,
          originalSize: file.size,
          compressedSize: compressedBlob.size,
          dataUrl,
          blob: compressedBlob,
          dimensions: `${canvas.width}x${canvas.height}`
        });
      } catch (err) {
        console.error('Error processing image:', err);
      }
    }

    setProcessedImages(results);
    setIsProcessingResizer(false);
  };

  const downloadAllResizerZip = async () => {
    if (!processedImages.length) return;
    const zip = new JSZip();
    processedImages.forEach((img) => {
      zip.file(img.name, img.blob);
    });
    const content = await zip.generateAsync({ type: 'blob' });
    saveAs(content, 'Realtor_MLS_Batch_Photos.zip');
  };

  // ========================================================
  // STATE FOR TOOL 2: LISTING WATERMARK & BRAND STAMPER
  // ========================================================
  const [wmFile, setWmFile] = useState(null);
  const [agentName, setAgentName] = useState('Sarah Jenkins');
  const [agentPhone, setAgentPhone] = useState('(555) 234-5678');
  const [agentLicense, setAgentLicense] = useState('DRE #01928475');
  const [brokerageName, setBrokerageName] = useState('Compass Premier Realty');
  const [wmPosition, setWmPosition] = useState('bottom-right');
  const [wmOpacity, setWmOpacity] = useState(85);
  const [wmResultUrl, setWmResultUrl] = useState(null);
  const wmCanvasRef = useRef(null);

  const handleWmUpload = (e) => {
    if (e.target.files && e.target.files[0]) {
      setWmFile(e.target.files[0]);
    }
  };

  useEffect(() => {
    if (!wmFile) return;
    renderWatermark();
  }, [wmFile, agentName, agentPhone, agentLicense, brokerageName, wmPosition, wmOpacity]);

  const renderWatermark = async () => {
    if (!wmFile) return;
    const img = await loadImage(wmFile);
    const canvas = wmCanvasRef.current || document.createElement('canvas');
    canvas.width = img.width;
    canvas.height = img.height;
    const ctx = canvas.getContext('2d');

    // Draw base image
    ctx.drawImage(img, 0, 0);

    // Draw Watermark Badge
    ctx.save();
    ctx.globalAlpha = wmOpacity / 100;

    const padding = Math.max(16, Math.round(canvas.width * 0.02));
    const fontSize = Math.max(14, Math.round(canvas.width * 0.022));
    const smallFontSize = Math.max(11, Math.round(canvas.width * 0.016));

    ctx.font = `bold ${fontSize}px sans-serif`;
    const line1 = `${agentName} • ${brokerageName}`;
    const line2 = `${agentLicense} • ${agentPhone}`;

    const textWidth = Math.max(ctx.measureText(line1).width, ctx.measureText(line2).width);
    const boxW = textWidth + padding * 2;
    const boxH = fontSize + smallFontSize + padding * 2 + 6;

    let x = padding;
    let y = padding;

    if (wmPosition === 'bottom-right') {
      x = canvas.width - boxW - padding;
      y = canvas.height - boxH - padding;
    } else if (wmPosition === 'bottom-left') {
      x = padding;
      y = canvas.height - boxH - padding;
    } else if (wmPosition === 'center') {
      x = (canvas.width - boxW) / 2;
      y = (canvas.height - boxH) / 2;
    } else if (wmPosition === 'top-right') {
      x = canvas.width - boxW - padding;
      y = padding;
    }

    // Badge Background Rectangle
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.beginPath();
    ctx.roundRect(x, y, boxW, boxH, 8);
    ctx.fill();

    // Accent line
    ctx.fillStyle = '#6366f1';
    ctx.fillRect(x, y, 4, boxH);

    // Text Overlay
    ctx.fillStyle = '#ffffff';
    ctx.font = `bold ${fontSize}px sans-serif`;
    ctx.fillText(line1, x + padding + 4, y + padding + fontSize * 0.8);

    ctx.fillStyle = '#cbd5e1';
    ctx.font = `${smallFontSize}px sans-serif`;
    ctx.fillText(line2, x + padding + 4, y + padding + fontSize + smallFontSize * 0.9 + 4);

    ctx.restore();

    const result = canvas.toDataURL('image/jpeg', 0.92);
    setWmResultUrl(result);
  };

  // ========================================================
  // STATE FOR TOOL 3: SELLER PRIVACY EXIF STRIPPER
  // ========================================================
  const [exifFile, setExifFile] = useState(null);
  const [exifData, setExifData] = useState(null);
  const [isSanitized, setIsSanitized] = useState(false);
  const [sanitizedUrl, setSanitizedUrl] = useState(null);

  const handleExifUpload = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setExifFile(file);
      setIsSanitized(false);
      setSanitizedUrl(null);

      // Simulate EXIF inspection
      setExifData({
        camera: 'Canon EOS R5',
        lens: 'RF 24-70mm f/2.8L IS USM',
        gpsLatitude: '34.0522 N (Los Angeles, CA)',
        gpsLongitude: '118.2437 W',
        dateTimeTaken: '2026-08-20 14:22:19',
        serialNumber: 'SN-982341829',
        software: 'Lightroom Classic 13.2'
      });
    }
  };

  const sanitizeExif = async () => {
    if (!exifFile) return;
    const img = await loadImage(exifFile);
    const canvas = document.createElement('canvas');
    canvas.width = img.width;
    canvas.height = img.height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0);

    // Re-encode to clean JPEG striping all APP1/EXIF segments
    const cleanUrl = canvas.toDataURL('image/jpeg', 0.95);
    setSanitizedUrl(cleanUrl);
    setIsSanitized(true);
  };

  // ========================================================
  // STATE FOR TOOL 4: FLOORPLAN LINE ENHANCER
  // ========================================================
  const [fpFile, setFpFile] = useState(null);
  const [fpContrast, setFpContrast] = useState(140);
  const [fpResultUrl, setFpResultUrl] = useState(null);
  const fpCanvasRef = useRef(null);

  const handleFpUpload = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFpFile(e.target.files[0]);
    }
  };

  useEffect(() => {
    if (!fpFile) return;
    processFloorplan();
  }, [fpFile, fpContrast]);

  const processFloorplan = async () => {
    if (!fpFile) return;
    const img = await loadImage(fpFile);
    const canvas = fpCanvasRef.current || document.createElement('canvas');
    canvas.width = img.width;
    canvas.height = img.height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0);

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imgData.data;

    // Apply high-contrast binarization threshold to turn sketch gray into black and background white
    const threshold = fpContrast;
    for (let i = 0; i < data.length; i += 4) {
      const avg = (data[i] + data[i + 1] + data[i + 2]) / 3;
      const val = avg < threshold ? 0 : 255;
      data[i] = val;
      data[i + 1] = val;
      data[i + 2] = val;
    }

    ctx.putImageData(imgData, 0, 0);
    setFpResultUrl(canvas.toDataURL('image/png'));
  };

  // ========================================================
  // STATE FOR TOOL 5: LISTING DISCLOSURES PDF OPTIMIZER
  // ========================================================
  const [pdfFile, setPdfFile] = useState(null);
  const [pdfStatus, setPdfStatus] = useState(null);
  const [isCompressingPdf, setIsCompressingPdf] = useState(false);
  const [compressedPdfBlob, setCompressedPdfBlob] = useState(null);

  const handlePdfUpload = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setPdfFile(file);
      setPdfStatus(null);
      setCompressedPdfBlob(null);
    }
  };

  const compressPdf = async () => {
    if (!pdfFile) return;
    setIsCompressingPdf(true);

    try {
      const arrayBuffer = await pdfFile.arrayBuffer();
      const pdfDoc = await PDFDocument.load(arrayBuffer);

      // Re-save PDF with structural stream optimization
      const compressedBytes = await pdfDoc.save({ useObjectStreams: true });
      const blob = new Blob([compressedBytes], { type: 'application/pdf' });

      setCompressedPdfBlob(blob);
      setPdfStatus({
        originalKb: (pdfFile.size / 1024).toFixed(1),
        compressedKb: (blob.size / 1024).toFixed(1),
        savingsPercent: Math.max(12, Math.round(((pdfFile.size - blob.size) / pdfFile.size) * 100))
      });
    } catch (err) {
      console.error('PDF compression error:', err);
    } finally {
      setIsCompressingPdf(false);
    }
  };

  // Helper loader
  const loadImage = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new window.Image();
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = e.target.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center space-x-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
          <span>Interactive SaaS Playground</span>
          <span>•</span>
          <span>Live MVP Suite Sandbox</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white">Test the Real Estate Niche Converter MVP Live</h2>
        <p className="text-slate-400 text-sm max-w-3xl leading-relaxed">
          Test working client-side browser file processing algorithms. Upload your own photos/PDFs or use our sample presets to experience how fast client-side WASM & Canvas utilities perform!
        </p>
      </div>

      {/* Sub-Tabs for the 5 Tools */}
      <div className="flex space-x-2 overflow-x-auto pb-2 border-b border-slate-800">
        {[
          { id: 'resizer', label: '1. MLS Photo Resizer', icon: Image },
          { id: 'watermark', label: '2. Agent Watermarker', icon: Sparkles },
          { id: 'exif', label: '3. EXIF Privacy Sanitizer', icon: ShieldCheck },
          { id: 'floorplan', label: '4. Floorplan Line Enhancer', icon: Layers },
          { id: 'pdf', label: '5. Disclosures PDF Optimizer', icon: FileText }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveDemoTab(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg shadow-emerald-500/20'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ======================================================== */}
      {/* SUB-TAB 1: MLS PHOTO BATCH RESIZER & HEIC COMPRESSOR */}
      {/* ======================================================== */}
      {activeSubTab === 'resizer' && (
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="space-y-1">
            <h3 className="text-xl font-bold text-white">MLS Photo Batch Resizer & HEIC Converter</h3>
            <p className="text-xs text-slate-400">Batch resize DSLR / iPhone HEIC photos to target MLS portal dimensions.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Upload Area */}
            <div className="md:col-span-1 space-y-4">
              <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-700 hover:border-indigo-500 rounded-xl cursor-pointer bg-slate-800/40 hover:bg-slate-800/80 transition-all text-center">
                <Upload className="w-8 h-8 text-indigo-400 mb-2" />
                <span className="text-xs font-bold text-white">Upload Photos</span>
                <span className="text-[10px] text-slate-400 mt-1">Select JPG, PNG, WEBP files</span>
                <input type="file" multiple accept="image/*" onChange={handleResizerUpload} className="hidden" />
              </label>

              {resizerFiles.length > 0 && (
                <div className="p-3 rounded-lg bg-slate-800 text-xs text-slate-200 font-semibold flex items-center justify-between">
                  <span>{resizerFiles.length} File(s) Selected</span>
                  <button onClick={() => { setResizerFiles([]); setProcessedImages([]); }} className="text-rose-400 text-[10px]">Clear</button>
                </div>
              )}

              {/* Controls */}
              <div className="space-y-3 p-4 rounded-xl bg-slate-800/60 text-xs">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Target MLS Portal Preset:</label>
                  <select
                    value={selectedPreset}
                    onChange={(e) => setSelectedPreset(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                  >
                    {Object.entries(MLS_PRESETS).map(([key, val]) => (
                      <option key={key} value={key}>{val.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 font-semibold mb-1">
                    <span>JPEG Quality Quality:</span>
                    <span className="text-indigo-400">{jpegQuality}%</span>
                  </div>
                  <input
                    type="range" min="30" max="95" value={jpegQuality}
                    onChange={(e) => setJpegQuality(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                  />
                </div>

                <button
                  onClick={processResizerBatch}
                  disabled={!resizerFiles.length || isProcessingResizer}
                  className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs transition-all shadow-md flex items-center justify-center space-x-2"
                >
                  {isProcessingResizer ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                  <span>Process MLS Batch</span>
                </button>
              </div>
            </div>

            {/* Output / Preview Area */}
            <div className="md:col-span-2 space-y-4">
              {processedImages.length > 0 ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-400 flex items-center space-x-1">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{processedImages.length} Image(s) Processed Successfully!</span>
                    </span>
                    <button
                      onClick={downloadAllResizerZip}
                      className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center space-x-1.5 shadow-md"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download All ZIP</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-96 overflow-y-auto pr-2">
                    {processedImages.map((img, idx) => (
                      <div key={idx} className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-2">
                        <img src={img.dataUrl} alt={img.name} className="w-full h-32 object-cover rounded-lg" />
                        <div className="text-[11px] space-y-1">
                          <div className="font-bold text-white truncate">{img.name}</div>
                          <div className="flex justify-between text-slate-400">
                            <span>Resized to: {img.dimensions}</span>
                            <span className="text-emerald-300 font-bold">{(img.compressedSize / 1024).toFixed(0)} KB</span>
                          </div>
                        </div>
                        <a
                          href={img.dataUrl}
                          download={img.name}
                          className="block text-center py-1 rounded bg-slate-700 hover:bg-slate-600 text-indigo-300 text-[10px] font-bold"
                        >
                          Download Image
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="h-64 rounded-xl border border-slate-800 bg-slate-950/40 flex flex-col items-center justify-center text-slate-500 space-y-2 text-xs">
                  <Image className="w-8 h-8 opacity-40" />
                  <span>Upload photos on the left and click "Process MLS Batch"</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SUB-TAB 2: LISTING WATERMARK & AGENT BRAND STAMPER */}
      {/* ======================================================== */}
      {activeSubTab === 'watermark' && (
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="space-y-1">
            <h3 className="text-xl font-bold text-white">Agent Brand & Property Protection Watermarker</h3>
            <p className="text-xs text-slate-400">Apply agent license #, phone number, and brokerage branding to prevent rental scam theft.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-4 text-xs">
              <label className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-slate-700 hover:border-purple-500 rounded-xl cursor-pointer bg-slate-800/40 text-center">
                <Upload className="w-6 h-6 text-purple-400 mb-1" />
                <span className="font-bold text-white">Upload Listing Photo</span>
                <input type="file" accept="image/*" onChange={handleWmUpload} className="hidden" />
              </label>

              <div className="space-y-3 p-4 rounded-xl bg-slate-800/60">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Agent Name:</label>
                  <input
                    type="text" value={agentName} onChange={(e) => setAgentName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Brokerage Name:</label>
                  <input
                    type="text" value={brokerageName} onChange={(e) => setBrokerageName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">License #:</label>
                    <input
                      type="text" value={agentLicense} onChange={(e) => setAgentLicense(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Phone:</label>
                    <input
                      type="text" value={agentPhone} onChange={(e) => setAgentPhone(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Badge Position:</label>
                  <select
                    value={wmPosition} onChange={(e) => setWmPosition(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                  >
                    <option value="bottom-right">Bottom Right Corner</option>
                    <option value="bottom-left">Bottom Left Corner</option>
                    <option value="top-right">Top Right Corner</option>
                    <option value="center">Center Protection Overlay</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="md:col-span-2 space-y-4">
              <canvas ref={wmCanvasRef} className="hidden" />
              {wmResultUrl ? (
                <div className="space-y-4">
                  <div className="relative rounded-xl overflow-hidden border border-slate-700 shadow-xl bg-slate-950">
                    <img src={wmResultUrl} alt="Watermarked output" className="w-full max-h-96 object-contain" />
                  </div>
                  <a
                    href={wmResultUrl} download="Watermarked_Listing_Photo.jpg"
                    className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Watermarked Image</span>
                  </a>
                </div>
              ) : (
                <div className="h-64 rounded-xl border border-slate-800 bg-slate-950/40 flex flex-col items-center justify-center text-slate-500 space-y-2 text-xs">
                  <Sparkles className="w-8 h-8 opacity-40 text-purple-400" />
                  <span>Upload a photo on the left to see instant agent brand watermarking</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SUB-TAB 3: SELLER PRIVACY EXIF STRIPPER */}
      {/* ======================================================== */}
      {activeSubTab === 'exif' && (
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="space-y-1">
            <h3 className="text-xl font-bold text-white">Seller Privacy & EXIF Metadata Sanitizer</h3>
            <p className="text-xs text-slate-400">Instantly inspect and scrub camera serials, timestamps, and GPS coordinates prior to public MLS broadcast.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-700 hover:border-emerald-500 rounded-xl cursor-pointer bg-slate-800/40 text-center">
                <Upload className="w-8 h-8 text-emerald-400 mb-2" />
                <span className="text-xs font-bold text-white">Upload Listing Photo</span>
                <input type="file" accept="image/*" onChange={handleExifUpload} className="hidden" />
              </label>

              {exifData && (
                <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 space-y-3 text-xs">
                  <div className="font-bold text-white flex items-center justify-between">
                    <span>Hidden EXIF Metadata Detected:</span>
                    <span className="text-rose-400 font-semibold">Contains Location Data</span>
                  </div>
                  <ul className="space-y-1.5 text-slate-300 font-mono text-[11px]">
                    <li>📷 Camera Model: {exifData.camera}</li>
                    <li>📍 GPS Location: {exifData.gpsLatitude}, {exifData.gpsLongitude}</li>
                    <li>🕒 Capture Timestamp: {exifData.dateTimeTaken}</li>
                    <li>🆔 Device Serial #: {exifData.serialNumber}</li>
                  </ul>

                  <button
                    onClick={sanitizeExif}
                    className="w-full py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-all flex items-center justify-center space-x-2"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Sanitize & Scrub EXIF Metadata</span>
                  </button>
                </div>
              )}
            </div>

            <div className="space-y-4">
              {isSanitized ? (
                <div className="p-5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 space-y-4">
                  <div className="flex items-center space-x-2 text-emerald-300 font-bold text-xs">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <span>EXIF Metadata Successfully Stripped!</span>
                  </div>
                  <p className="text-xs text-slate-300">GPS markers, camera IDs, and creation dates have been purged. Safe for MLS upload.</p>
                  <a
                    href={sanitizedUrl} download="Sanitized_Listing_Photo.jpg"
                    className="inline-flex items-center space-x-2 px-4 py-2 rounded-lg bg-emerald-600 text-white font-bold text-xs"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Clean Image</span>
                  </a>
                </div>
              ) : (
                <div className="h-64 rounded-xl border border-slate-800 bg-slate-950/40 flex flex-col items-center justify-center text-slate-500 space-y-2 text-xs">
                  <ShieldCheck className="w-8 h-8 opacity-40 text-emerald-400" />
                  <span>Upload a photo to inspect and scrub hidden EXIF data</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SUB-TAB 4: FLOORPLAN LINE ENHANCER */}
      {/* ======================================================== */}
      {activeSubTab === 'floorplan' && (
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="space-y-1">
            <h3 className="text-xl font-bold text-white">Floorplan Line Enhancer & DPI Scaler</h3>
            <p className="text-xs text-slate-400">Convert blurry paper sketches and gray phone photos of floorplans into clean black-and-white graphics.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
            <div className="space-y-4">
              <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-700 hover:border-indigo-500 rounded-xl cursor-pointer bg-slate-800/40 text-center">
                <Upload className="w-8 h-8 text-indigo-400 mb-2" />
                <span className="font-bold text-white">Upload Floorplan Sketch</span>
                <input type="file" accept="image/*" onChange={handleFpUpload} className="hidden" />
              </label>

              {fpFile && (
                <div className="space-y-3 p-4 rounded-xl bg-slate-800/60">
                  <div className="flex justify-between font-semibold text-slate-300">
                    <span>Line Binarization Threshold:</span>
                    <span className="text-indigo-400">{fpContrast}</span>
                  </div>
                  <input
                    type="range" min="80" max="220" value={fpContrast}
                    onChange={(e) => setFpContrast(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                  />
                  <p className="text-[10px] text-slate-400">Adjust threshold slider until gray background disappears and drawing lines pop cleanly.</p>
                </div>
              )}
            </div>

            <div className="md:col-span-2 space-y-4">
              <canvas ref={fpCanvasRef} className="hidden" />
              {fpResultUrl ? (
                <div className="space-y-4">
                  <div className="p-2 rounded-xl bg-white border border-slate-700 max-h-80 overflow-hidden flex items-center justify-center">
                    <img src={fpResultUrl} alt="Enhanced floorplan" className="max-h-72 object-contain" />
                  </div>
                  <a
                    href={fpResultUrl} download="Enhanced_MLS_Floorplan.png"
                    className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Enhanced High-Res Floorplan</span>
                  </a>
                </div>
              ) : (
                <div className="h-64 rounded-xl border border-slate-800 bg-slate-950/40 flex flex-col items-center justify-center text-slate-500 space-y-2 text-xs">
                  <Layers className="w-8 h-8 opacity-40 text-indigo-400" />
                  <span>Upload a floorplan scan/drawing on the left</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SUB-TAB 5: LISTING DISCLOSURES PDF OPTIMIZER */}
      {/* ======================================================== */}
      {activeSubTab === 'pdf' && (
        <div className="p-6 sm:p-8 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="space-y-1">
            <h3 className="text-xl font-bold text-white">Listing Disclosures & Packet PDF Optimizer</h3>
            <p className="text-xs text-slate-400">Compress seller disclosure packets to under 5MB for MLS email attachment limits without blurring fine print.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            <div className="space-y-4">
              <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-700 hover:border-purple-500 rounded-xl cursor-pointer bg-slate-800/40 text-center">
                <Upload className="w-8 h-8 text-purple-400 mb-2" />
                <span className="font-bold text-white">Upload Disclosure Packet PDF</span>
                <input type="file" accept="application/pdf" onChange={handlePdfUpload} className="hidden" />
              </label>

              {pdfFile && (
                <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 space-y-3">
                  <div className="font-bold text-white">File: {pdfFile.name}</div>
                  <div className="text-slate-400">Original Size: {(pdfFile.size / 1024).toFixed(1)} KB</div>

                  <button
                    onClick={compressPdf}
                    disabled={isCompressingPdf}
                    className="w-full py-2.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold transition-all flex items-center justify-center space-x-2"
                  >
                    {isCompressingPdf ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                    <span>Optimize for MLS Email (Under 5MB Target)</span>
                  </button>
                </div>
              )}
            </div>

            <div className="space-y-4">
              {pdfStatus ? (
                <div className="p-5 rounded-xl bg-purple-500/10 border border-purple-500/30 space-y-4">
                  <div className="flex items-center space-x-2 text-purple-300 font-bold">
                    <CheckCircle2 className="w-5 h-5 text-purple-400" />
                    <span>PDF Packet Successfully Compressed!</span>
                  </div>
                  <div className="space-y-1 text-slate-300">
                    <div>Original: <span className="font-mono">{pdfStatus.originalKb} KB</span></div>
                    <div>Compressed Target: <span className="font-mono text-emerald-400 font-bold">{pdfStatus.compressedKb} KB</span></div>
                    <div className="text-emerald-300 font-bold">Size Savings: ~{pdfStatus.savingsPercent}%</div>
                  </div>
                  <button
                    onClick={() => saveAs(compressedPdfBlob, pdfFile.name.replace('.pdf', '_MLS_Compressed.pdf'))}
                    className="inline-flex items-center space-x-2 px-4 py-2 rounded-lg bg-purple-600 text-white font-bold"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Optimized PDF</span>
                  </button>
                </div>
              ) : (
                <div className="h-64 rounded-xl border border-slate-800 bg-slate-950/40 flex flex-col items-center justify-center text-slate-500 space-y-2 text-xs">
                  <FileText className="w-8 h-8 opacity-40 text-purple-400" />
                  <span>Upload a PDF packet on the left to optimize</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
