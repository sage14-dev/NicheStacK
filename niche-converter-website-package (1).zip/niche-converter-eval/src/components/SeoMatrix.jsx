import React, { useState } from 'react';
import { KEYWORD_RESEARCH } from '../data/strategyData';
import { Search, Filter, ArrowUpRight, TrendingUp, DollarSign, Layers } from 'lucide-react';

export default function SeoMatrix() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTool, setSelectedTool] = useState('All');

  const toolsList = ['All', ...new Set(KEYWORD_RESEARCH.map((k) => k.tool))];

  const filteredKeywords = KEYWORD_RESEARCH.filter((item) => {
    const matchesSearch = item.keyword.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTool = selectedTool === 'All' || item.tool === selectedTool;
    return matchesSearch && matchesTool;
  });

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center space-x-2 text-indigo-400 text-xs font-bold uppercase tracking-wider">
          <span>Search Demand Analysis</span>
          <span>•</span>
          <span>Long-Tail Keyword Opportunity Matrix</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white">Target Keyword Intelligence & Search Demand</h2>
        <p className="text-slate-400 text-sm max-w-3xl leading-relaxed">
          High-intent, low-difficulty search queries that generic tools like SmallPDF ignore. These form the programmatic landing page structure for organic acquisition.
        </p>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search target keywords..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <span className="text-xs text-slate-400 font-semibold whitespace-nowrap">Target Tool:</span>
          <select
            value={selectedTool}
            onChange={(e) => setSelectedTool(e.target.value)}
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
          >
            {toolsList.map((t, idx) => (
              <option key={idx} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Keywords Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-800/80 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4">Search Keyword Query</th>
                <th className="py-3.5 px-4">Monthly Searches</th>
                <th className="py-3.5 px-4">Keyword Difficulty (KD)</th>
                <th className="py-3.5 px-4">Google Ad CPC</th>
                <th className="py-3.5 px-4">Target Converter Tool</th>
                <th className="py-3.5 px-4">Intent Type</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredKeywords.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-white flex items-center space-x-2">
                    <span>"{row.keyword}"</span>
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-emerald-400">
                    {row.volume.toLocaleString()} / mo
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                      KD {row.kd} (Easy)
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-bold text-amber-300">
                    ${row.cpc.toFixed(2)}
                  </td>
                  <td className="py-3.5 px-4 text-slate-300 font-medium">{row.tool}</td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[10px] font-semibold border border-indigo-500/30">
                      {row.intent}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
