import React from 'react';
import { Layers, Rocket, ShieldAlert, BarChart3, Search, PlayCircle, Download, CheckCircle2, Award } from 'lucide-react';

export default function Header({ activeTab, setActiveTab, onExportReport }) {
  const navItems = [
    { id: 'summary', label: 'Executive Brief', icon: Rocket },
    { id: 'validation', label: '1. Niche Validation', icon: Layers },
    { id: 'tools', label: '2. 5-Tool Blueprint', icon: Award },
    { id: 'risks', label: '3. Risks & Moats', icon: ShieldAlert },
    { id: 'calculator', label: 'Financial ROI Model', icon: BarChart3 },
    { id: 'seo', label: 'SEO Keyword Matrix', icon: Search },
    { id: 'demo', label: '⚡ Live MVP Sandbox', icon: PlayCircle, highlight: true }
  ];

  return (
    <header className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('summary')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-purple-500 flex items-center justify-center shadow-lg shadow-indigo-500/20 ring-1 ring-white/20">
              <Layers className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-lg tracking-tight text-white">NicheStack</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-medium border border-indigo-500/30">
                  SaaS Strategist
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium">Niche File Converter Validation Suite</p>
            </div>
          </div>

          {/* Export Button & Quick Badge */}
          <div className="flex items-center space-x-3">
            <div className="hidden md:flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
              <CheckCircle2 className="w-4 h-4" />
              <span>Verdict: Strong Pursue (Real Estate Niche)</span>
            </div>

            <button
              onClick={onExportReport}
              className="flex items-center space-x-2 px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all shadow-sm active:scale-95"
              title="Export complete strategy assessment report"
            >
              <Download className="w-4 h-4 text-indigo-400" />
              <span className="hidden sm:inline">Export Executive Report</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 overflow-x-auto no-scrollbar py-2 border-t border-slate-800/60">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all duration-200 ${
                  isActive
                    ? item.highlight
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-md shadow-emerald-500/20'
                      : 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                    : item.highlight
                    ? 'bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20 border border-emerald-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : item.highlight ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
