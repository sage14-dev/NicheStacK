import React, { useState } from 'react';
import { TOP_NICHE_TOOLS } from '../data/strategyData';
import { Award, Zap, Code, Search, DollarSign, CheckCircle2, ArrowRight, Layers, FileText, Image, ShieldCheck, Sparkles } from 'lucide-react';

export default function ToolRoadmap({ setActiveTab }) {
  const [selectedTool, setSelectedTool] = useState(TOP_NICHE_TOOLS[0]);

  const toolIcons = [Image, FileText, Sparkles, Layers, ShieldCheck];

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center space-x-2 text-purple-400 text-xs font-bold uppercase tracking-wider">
          <span>Requirement 2 Blueprint</span>
          <span>•</span>
          <span>Top Niche: Real Estate Agents & Brokers</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white">The First 5 Converters & Utilities to Build</h2>
        <p className="text-slate-400 text-sm max-w-3xl leading-relaxed">
          Product specification for the initial 5 MVP tools. Each tool directly targets a high-frequency real estate workflow bottleneck with a built-in freemium-to-paid conversion trigger.
        </p>
      </div>

      {/* 5 Tools Selector Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {TOP_NICHE_TOOLS.map((tool, idx) => {
          const Icon = toolIcons[idx] || Image;
          const isSelected = selectedTool.id === tool.id;
          return (
            <button
              key={tool.id}
              onClick={() => setSelectedTool(tool)}
              className={`p-4 rounded-xl text-left border transition-all duration-200 flex flex-col justify-between space-y-3 ${
                isSelected
                  ? 'bg-purple-950/40 border-purple-500/80 shadow-lg shadow-purple-500/10 ring-1 ring-purple-500/40'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className={`p-2 rounded-lg ${isSelected ? 'bg-purple-500/20 text-purple-300' : 'bg-slate-800 text-slate-400'}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-bold text-slate-500">TOOL 0{idx + 1}</span>
              </div>
              <div>
                <h4 className="font-bold text-white text-xs leading-snug line-clamp-2">{tool.name}</h4>
                <p className="text-[11px] text-purple-300 font-medium mt-1">{tool.searchVolume}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Tool Specification Card */}
      <div className="p-6 sm:p-8 rounded-2xl bg-slate-900 border border-slate-800 space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <div className="space-y-2 max-w-2xl">
            <span className="px-2.5 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-bold border border-purple-500/30">
              Tool Specification Blueprint
            </span>
            <h3 className="text-2xl font-black text-white">{selectedTool.name}</h3>
            <p className="text-xs text-slate-300 leading-relaxed">{selectedTool.tagline}</p>
          </div>

          <div className="flex items-center space-x-3">
            <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-right">
              <div className="text-[11px] text-slate-400">Monthly Search Volume</div>
              <div className="text-lg font-black text-emerald-400">{selectedTool.searchVolume}</div>
            </div>
            <button
              onClick={() => setActiveTab('demo')}
              className="px-4 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-extrabold text-xs shadow-lg shadow-purple-600/20 transition-all active:scale-95 flex items-center space-x-1.5"
            >
              <Zap className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
              <span>Test MVP Demo</span>
            </button>
          </div>
        </div>

        {/* 3 Core Pillars: Utility, Specificity, Search Signals */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Column 1: Conversion & Utility */}
          <div className="p-5 rounded-xl bg-slate-800/40 border border-slate-700/60 space-y-3">
            <div className="flex items-center space-x-2 text-indigo-400 text-xs font-bold uppercase tracking-wider">
              <Code className="w-4 h-4" />
              <span>1. File Utility Provided</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{selectedTool.utility}</p>
          </div>

          {/* Column 2: Profession Specificity */}
          <div className="p-5 rounded-xl bg-slate-800/40 border border-slate-700/60 space-y-3">
            <div className="flex items-center space-x-2 text-purple-400 text-xs font-bold uppercase tracking-wider">
              <Award className="w-4 h-4" />
              <span>2. Why Specific To Realtors</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{selectedTool.specificity}</p>
          </div>

          {/* Column 3: Technical Architecture & WASM */}
          <div className="p-5 rounded-xl bg-slate-800/40 border border-slate-700/60 space-y-3">
            <div className="flex items-center space-x-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
              <Zap className="w-4 h-4" />
              <span>3. Tech Architecture</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{selectedTool.technicalSpec}</p>
          </div>
        </div>

        {/* Search Keywords & Monetization Hook */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          {/* Target Long-Tail SEO Keywords */}
          <div className="space-y-3 p-5 rounded-xl bg-slate-950/60 border border-slate-800">
            <h4 className="font-bold text-white text-xs flex items-center space-x-2">
              <Search className="w-4 h-4 text-indigo-400" />
              <span>Primary Long-Tail SEO Target Queries</span>
            </h4>
            <div className="flex flex-wrap gap-2">
              {selectedTool.primaryKeywords.map((kw, idx) => (
                <span key={idx} className="px-2.5 py-1 rounded-md bg-indigo-500/10 text-indigo-300 text-xs font-medium border border-indigo-500/20">
                  "{kw}"
                </span>
              ))}
            </div>
          </div>

          {/* Monetization Trigger */}
          <div className="space-y-3 p-5 rounded-xl bg-slate-950/60 border border-slate-800">
            <h4 className="font-bold text-white text-xs flex items-center space-x-2">
              <DollarSign className="w-4 h-4 text-amber-400" />
              <span>Freemium → Paid Conversion Trigger</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">{selectedTool.monetizationHook}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
