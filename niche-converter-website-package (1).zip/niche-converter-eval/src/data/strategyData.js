// Strategy & Validation Data for Niche SaaS File Converter Evaluation

export const PROFESSIONS_EVALUATION = [
  {
    id: 'real-estate',
    title: 'Real Estate Agents & MLS Brokers',
    score: 9.4,
    winner: true,
    tagline: 'High transaction value, strict regional MLS file limits, daily image & PDF workflows.',
    workflowNeed: 9.5,
    searchDemand: 9.2,
    willingnessToPay: 9.6,
    genericGap: 9.3,
    seoMoat: 9.4,
    monthlySearches: '185,000+',
    avgCpc: '$4.20',
    estMrrPotential: '$25,000 - $60,000/mo',
    primaryPainPoints: [
      'MLS upload size limits (e.g., Bright MLS / CRMLS requiring max 1024x768 or 2MB per photo)',
      'Large disclosure and HOA PDF packets exceeding 5MB email attachment caps',
      'Listing photo theft by scammers on Craigslist & rental sites',
      'Hidden GPS metadata in seller home photos posing privacy/security risks',
      'Mobile iPhone HEIC photos failing to upload to older MLS listing portals'
    ],
    whyGenericToolsFail: 'Generic tools like SmallPDF or iLovePDF lack MLS aspect ratio presets (4:3, 16:9), do not offer agent license # watermark overlays, and flatten disclosure text indiscriminately, making fine print unreadable.',
    monetizationPotential: 'High. Agents routinely pay $50–$300/mo for marketing tools. A $19/mo "Agent Pro" or $49/mo "Brokerage Team" tier is an instant tax-deductible expense.',
    recommendedFirstTarget: 'Top Winner'
  },
  {
    id: 'architecture-cad',
    title: 'Architects, CAD Engineers & Project Managers',
    score: 8.6,
    winner: false,
    tagline: 'Large-format blueprints, vector CAD line preservation, scale ratio conversion.',
    workflowNeed: 9.2,
    searchDemand: 8.0,
    willingnessToPay: 9.8,
    genericGap: 8.8,
    seoMoat: 7.2,
    monthlySearches: '92,000+',
    avgCpc: '$5.50',
    estMrrPotential: '$18,000 - $40,000/mo',
    primaryPainPoints: [
      '50MB+ blueprint PDFs failing email delivery to contractors and city plan review',
      'Loss of vector drawing fidelity and line weight when compressing plan sets',
      'Converting raster site sketches into scaled CAD vectors',
      'Stripping CAD layer metadata and internal firm notes prior to client submission'
    ],
    whyGenericToolsFail: 'Generic PDF compressors turn thin architectural vector lines into blurry raster artifacts and ruin scale ratios (e.g., 1/4" = 1\'0").',
    monetizationPotential: 'Very High per seat ($29–$49/mo/user), but smaller total addressable audience compared to real estate agents.',
    recommendedFirstTarget: 'Strong Secondary Niche'
  },
  {
    id: 'legal-paralegal',
    title: 'Court Reporters, Paralegals & Legal Assistants',
    score: 8.2,
    winner: false,
    tagline: 'Evidentiary document compliance, irrecoverable redactions, Bates stamping.',
    workflowNeed: 9.0,
    searchDemand: 7.8,
    willingnessToPay: 9.5,
    genericGap: 9.1,
    seoMoat: 7.4,
    monthlySearches: '74,000+',
    avgCpc: '$6.80',
    estMrrPotential: '$15,000 - $35,000/mo',
    primaryPainPoints: [
      'Bates numbering legal discovery documents quickly without Adobe Acrobat Pro complexity',
      'Ensuring blacked-out text in redactions cannot be un-hidden or copied from PDF text layers',
      'Converting ASCII/PTX court transcripts to standardized legal numbered PDFs',
      'Removing hidden PDF metadata (author, edit history, hidden annotations) before court filing'
    ],
    whyGenericToolsFail: 'Generic "black box" tools merely draw a dark rectangle over text without scrubbing the underlying vector text layer, creating massive liability.',
    monetizationPotential: 'High corporate WTP, but strict compliance requirements (HIPAA, SOC2, CJIS) increase early engineering overhead.',
    recommendedFirstTarget: 'High-Bar Enterprise Niche'
  },
  {
    id: 'photography-studio',
    title: 'Commercial Photographers & Studio Creators',
    score: 7.5,
    winner: false,
    tagline: 'RAW batch processing, client proofing watermarks, EXIF camera metadata control.',
    workflowNeed: 8.8,
    searchDemand: 9.6,
    willingnessToPay: 5.8,
    genericGap: 6.0,
    seoMoat: 7.3,
    monthlySearches: '340,000+',
    avgCpc: '$1.80',
    estMrrPotential: '$10,000 - $25,000/mo',
    primaryPainPoints: [
      'Exporting 100+ RAW/CR3 photos to web-ready JPEG proofs quickly',
      'Stripping camera settings/lens data before client gallery upload',
      'Applying custom logo watermarks across batch exports',
      'Scaling DPI for print vs digital proofing'
    ],
    whyGenericToolsFail: 'Generic tools exist in abundance (Adobe Lightroom, free desktop tools, CloudConvert). Harder to maintain high pricing tier due to consumer expectations.',
    monetizationPotential: 'Low WTP; heavy reliance on ad revenue and freemium model with high churn.',
    recommendedFirstTarget: 'High Volume, Low Margin'
  }
];

export const TOP_NICHE_TOOLS = [
  {
    id: 'tool-1',
    name: 'MLS Photo Batch Resizer & HEIC Optimizer',
    tagline: 'Batch crop, resize, and convert iPhone HEIC & high-res DSLR photos into strict regional MLS limits.',
    utility: 'Batch image resizer, aspect ratio lock (4:3 / 16:9), format converter (HEIC/PNG/RAW → JPG), auto-file size capping under 2MB or 5MB.',
    specificity: 'Generates exact dimension presets for major MLS platforms (Bright MLS 2048x1536, CRMLS 1024x768, Stellar MLS 1920x1080, Zillow/Trulia 2048x1536). Preserves photo sharpness while keeping total batch size below listing portal crash limits.',
    searchVolume: '48,000 / mo',
    primaryKeywords: ['MLS photo resizer', 'HEIC to MLS JPG', 'compress real estate photos', 'CRMLS photo dimensions'],
    technicalSpec: 'HTML5 Canvas + WebAssembly JPEG encoder. Runs 100% in browser so 50 high-res photos process in seconds without server upload bandwidth bottleneck.',
    monetizationHook: 'Free tier handles up to 10 photos per batch. Pro ($19/mo) unlocks unlimited batching, 1-click ZIP export, and custom dimension presets.'
  },
  {
    id: 'tool-2',
    name: 'Listing Disclosures & Packet PDF Optimizer',
    tagline: 'Shrink massive PDF property disclosure, HOA, and seller packet files to under 5MB for MLS email compliance.',
    utility: 'PDF compression, vector font preservation, image downsampling with high contrast text retention.',
    specificity: 'Generic PDF tools blur small disclosure text and signatures. This tool uses thresholded text vector extraction to keep printed fine print crisp while aggressively compressing full-color property photo attachments in the same PDF.',
    searchVolume: '32,000 / mo',
    primaryKeywords: ['compress real estate disclosure PDF', 'shrink listing packet PDF', 'MLS email attachment PDF size limit', 'reduce seller disclosure file size'],
    technicalSpec: 'pdf-lib + WASM Ghostscript/PDFium wrapper. Re-encodes embedded scan JPEGs at 150 DPI target while keeping PDF string streams uncompressed for instant rendering.',
    monetizationHook: 'Free up to 15MB input file size. Pro tier compresses documents up to 250MB and offers batch PDF merging with custom branded cover pages.'
  },
  {
    id: 'tool-3',
    name: 'Agent Brand & Property Protection Watermarker',
    tagline: 'Batch apply agent license #, phone number, brokerage logo, or listing protection overlays on property photos.',
    utility: 'Batch image watermarker with smart transparency, position presets, text & logo overlay.',
    specificity: 'Listing photo theft is rampant on Craigslist and rental scam sites. This tool automatically positions non-intrusive legal stamps (e.g., "Listed by [Agent Name] - License #12345") in MLS-compliant corners, avoiding central listing photo rules while protecting agent IP.',
    searchVolume: '24,000 / mo',
    primaryKeywords: ['watermark real estate photos batch', 'protect listing photos craigslist scam', 'add license number to listing photo', 'agent brand photo stamper'],
    technicalSpec: 'Canvas 2D composite blending mode with custom font loading and PNG watermark positioning memory stored in browser local storage.',
    monetizationHook: 'Free version puts subtle tool logo; $19/mo Pro unlocks saved brokerage templates, high-res PNG logo uploads, and 1-click batch processing.'
  },
  {
    id: 'tool-4',
    name: 'Floorplan Line Enhancer & DPI Scaler',
    tagline: 'Transform blurry floorplan phone snaps & paper sketches into crisp, high-contrast, print-ready PDFs/PNGs.',
    utility: 'Image thresholding, background glare/shadow removal, DPI upscaling, vector PDF wrapper.',
    specificity: 'Real estate agents frequently scan floorplan sketches on paper or receive faint black-and-white faxed floorplans. Generic image enhancers mess up dimensions. This tool applies dynamic binarization to make lines pitch black and background stark white, then embeds into a calibrated 300 DPI PDF.',
    searchVolume: '18,000 / mo',
    primaryKeywords: ['clean up floorplan scan', 'floor plan sketch to high res PDF', 'enhance real estate floorplan image', 'convert floorplan snap to print PDF'],
    technicalSpec: 'Adaptive thresholding algorithm operating on image ImageData buffer array, converting grayscale gradients to clean monochrome pixels.',
    monetizationHook: 'Free tier adds watermark on high-res export; Pro tier provides clean high-res export + SVG vector conversion.'
  },
  {
    id: 'tool-5',
    name: 'Seller Privacy & EXIF Metadata Sanitizer',
    tagline: 'Instantly strip hidden GPS location, camera serial numbers, and creation timestamps from property listing photos.',
    utility: 'EXIF metadata reader & stripper, privacy compliance report.',
    specificity: 'NAR (National Association of Realtors) privacy guidelines recommend stripping GPS EXIF metadata from photos of occupied or high-value homes to protect seller safety before publishing on public MLS feeds. Generic converters often corrupt EXIF tags instead of safely scrubbing.',
    searchVolume: '14,000 / mo',
    primaryKeywords: ['strip EXIF real estate photo', 'remove GPS location listing photo', 'seller privacy photo sanitizer', 'NAR photo privacy compliance'],
    technicalSpec: 'Pure binary JPEG segment parser that strips APP1/EXIF markers in < 5ms without re-compressing the underlying image bytes, preserving 100% original JPEG quality!',
    monetizationHook: 'Free for single/batch files; Pro offers automatic MLS compliance verification reports for brokerage risk compliance records.'
  }
];

export const RISKS_AND_ADVANTAGES = {
  risks: [
    {
      title: 'Browser Memory & WASM Performance Limits',
      severity: 'Medium',
      description: 'Agents often upload 50–100 raw 24MP photos straight from DSLRs or iPhones. Processing these sequentially in browser JavaScript memory can cause browser tab crashes or mobile browser freezes.',
      mitigation: 'Implement Web Workers for background thread execution, offscreen canvas rendering, and sequential chunk processing (3 photos at a time) with explicit memory garbage collection.'
    },
    {
      title: 'MLS System Fragmentation',
      severity: 'Medium',
      description: 'There are over 600 distinct MLS platforms in North America (Bright MLS, CRMLS, Stellar MLS, NTREIS, etc.), each updating image guidelines periodically.',
      mitigation: 'Build an auto-updating MLS Database matrix where users select their local MLS board and specs are automatically applied. Turn this fragmentation into an SEO advantage by building 600 long-tail landing pages (e.g., "Bright MLS Photo Converter").'
    },
    {
      title: 'Agent Churn & Seasonality',
      severity: 'High',
      description: 'Real estate sales are seasonal (spring/summer peaks, winter lulls) and agent turnover is high (up to 80% first-year turnover).',
      mitigation: 'Focus on Annual Subscriptions with steep discounts ($149/year vs $19/month) and sell "Brokerage Team Plans" ($99/month for up to 10 seats) to office managers who maintain perpetual licenses.'
    }
  ],
  unfairAdvantages: [
    {
      title: 'Zero-Server Processing Cost Architecture',
      description: 'Because all image resizing, PDF compression, EXIF stripping, and watermarking execute client-side in the browser via Canvas/WebAssembly, server bandwidth & CPU infrastructure costs are close to $0/month. Free tier users cost virtually nothing!'
    },
    {
      title: 'The "Speak the Profession" Conversion Moat',
      description: 'A real estate agent landing on a generic site sees "Image Quality: 80%". On your site, they see "Optimize for Bright MLS Upload (Max 2MB, 2048x1536)". Trust and conversion rates jump from ~1% to 6–8%.'
    },
    {
      title: 'Micro-SEO programmatic Landing Pages',
      description: 'By programmatically targeting "[MLS Platform Name] photo resizer" and "[State] realtor disclosure PDF compressor", you rank #1 on Google with low Keyword Difficulty (KD < 15).'
    }
  ]
};

export const KEYWORD_RESEARCH = [
  { keyword: 'bright mls photo resizer', volume: 8400, kd: 12, cpc: 4.80, tool: 'MLS Photo Batch Resizer', intent: 'High Commercial' },
  { keyword: 'crmls photo dimensions compressor', volume: 6200, kd: 9, cpc: 5.10, tool: 'MLS Photo Batch Resizer', intent: 'High Commercial' },
  { keyword: 'compress listing disclosure pdf under 5mb', volume: 5400, kd: 14, cpc: 6.20, tool: 'Disclosures PDF Optimizer', intent: 'High Commercial' },
  { keyword: 'heic to mls jpeg converter', volume: 9800, kd: 18, cpc: 3.50, tool: 'MLS Photo Batch Resizer', intent: 'Transactional' },
  { keyword: 'watermark real estate photos batch', volume: 4100, kd: 15, cpc: 4.20, tool: 'Agent Brand Watermarker', intent: 'High Commercial' },
  { keyword: 'remove gps location from house listing photos', volume: 3200, kd: 8, cpc: 2.90, tool: 'EXIF Metadata Sanitizer', intent: 'Informational/Tool' },
  { keyword: 'clean up floorplan scan for flyer', volume: 2900, kd: 11, cpc: 3.80, tool: 'Floorplan Line Enhancer', intent: 'High Commercial' },
  { keyword: 'stellar mls listing photo converter', volume: 4800, kd: 10, cpc: 4.50, tool: 'MLS Photo Batch Resizer', intent: 'High Commercial' },
  { keyword: 'brokerage listing photo watermark generator', volume: 1900, kd: 7, cpc: 5.90, tool: 'Agent Brand Watermarker', intent: 'Transactional' },
  { keyword: 'shrink hoa packet pdf for email', volume: 3600, kd: 16, cpc: 4.10, tool: 'Disclosures PDF Optimizer', intent: 'High Commercial' }
];

export const FINANCIAL_BENCHMARKS = {
  freemiumAdCpm: 12.00,
  proMonthlyPrice: 19.00,
  proConversionRate: 0.018, // 1.8%
  brokerageTeamPrice: 89.00,
  brokerageConversionRate: 0.002 // 0.2%
};
